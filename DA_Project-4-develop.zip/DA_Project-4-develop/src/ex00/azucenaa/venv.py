#!/usr/bin/env python3
import os

def main():
    try:
        env_path = os.environ["VIRTUAL_ENV"]
        print(f"Your current virtual env is {env_path}")
    except KeyError:
        print("VIRTUAL_ENV не обнаружен. Вероятно, окружение неактивно.")

if __name__ == "__main__":
    main()
