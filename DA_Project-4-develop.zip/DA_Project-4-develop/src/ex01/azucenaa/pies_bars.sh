#!/usr/bin/env bash

termgraph pies_bars_data.dat --color {cyan,magenta}
