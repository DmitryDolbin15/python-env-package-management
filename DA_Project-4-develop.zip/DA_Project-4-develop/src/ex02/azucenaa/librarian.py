import os
import sys
import subprocess
import shutil

# Ожидаемое имя виртуального окружения
EXPECTED_ENV_NAME = "waylonpe"

def check_env():
    current_env = os.environ.get("VIRTUAL_ENV")
    if current_env is None or EXPECTED_ENV_NAME not in current_env:
        raise EnvironmentError(f"Ошибка: скрипт должен выполняться внутри окружения '{EXPECTED_ENV_NAME}'.")

def install_packages():
    subprocess.run(["pip", "install", "-r", "requirements.txt"], check=True)

def list_installed_packages():
    result = subprocess.run(["pip", "freeze"], capture_output=True, text=True, check=True)
    installed_packages = result.stdout.strip()
    print(installed_packages)

    with open("requirements.txt", "w") as f:
        f.write(installed_packages)

def archive_env():
    env_path = os.environ.get("VIRTUAL_ENV")
    if env_path:
        archive_name = f"{EXPECTED_ENV_NAME}.zip"
        shutil.make_archive(EXPECTED_ENV_NAME, 'zip', env_path)
        print(f"Архивация завершена: {archive_name}")
    else:
        print("Ошибка: виртуальное окружение не найдено.")

if __name__ == "__main__":
    try:
        check_env()
        install_packages()
        list_installed_packages()
        archive_env()
    except Exception as e:
        sys.exit(f"Ошибка: {e}")
