#!/usr/bin/env python3

import sys
import requests
from bs4 import BeautifulSoup

#python3 -m cProfile -s time financial.py 'MSFT' 'Total Revenue' > profiling-sleep.txt

YAHOO_FINANCE_URL = "https://finance.yahoo.com/quote/{}/financials?p={}"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/91.0.4472.124 Safari/537.36"
}

def get_financial_data(ticker, field):

    url = YAHOO_FINANCE_URL.format(ticker, ticker.upper())
    
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        response.raise_for_status() 
    except requests.RequestException as e:
        raise Exception(f"Ошибка при загрузке страницы: {e}")

    soup = BeautifulSoup(response.text, "html.parser")

    # Найти все элементы с классом 'rowTitle'
    row_titles = soup.find_all("div", class_=lambda x: x and "rowTitle" in x)

    for row in row_titles:
        # Проверяем, соответствует ли название запрашиваемому полю
        if row.text.strip().lower() == field.lower():
            # Предполагается, что значения находятся в следующих sibling div'ах
            parent = row.find_parent("div", class_="row")  # Находим родительский div с классом 'row'
            if not parent:
                continue  # Если родитель не найден, пропускаем

            # Находим все div'ы с классом 'column yf-t22klz' внутри родителя
            data_columns = parent.find_all("div", class_=lambda x: x and "column" in x)
            data = [col.text.strip().replace(',', '') for col in data_columns]

            return tuple(data)

    raise Exception(f"Поле '{field}' не найдено на странице.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Использование: ./financial.py 'TICKER' 'FIELD_NAME'")
        sys.exit(1)

    ticker_symbol = sys.argv[1]
    field_name = sys.argv[2]

    try:
        result = get_financial_data(ticker_symbol, field_name)
        print(result)
    except Exception as e:
        print(f"Ошибка: {e}")
        sys.exit(1)
