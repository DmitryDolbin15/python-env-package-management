#!/usr/bin/env python3

import sys
import httpx
from bs4 import BeautifulSoup

YAHOO_FINANCE_URL = "https://finance.yahoo.com/quote/{}/financials/?p={}"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/91.0.4472.124 Safari/537.36",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
    "Connection": "keep-alive"
}

def get_financial_data(ticker, field):
    url = YAHOO_FINANCE_URL.format(ticker.upper(), ticker.upper())
    
    try:
        with httpx.Client(timeout=10, follow_redirects=True) as client:
            response = client.get(url, headers=HEADERS)
            response.raise_for_status()
    except httpx.RequestError as e:
        raise Exception(f"Ошибка при загрузке страницы: {e}")
    except httpx.HTTPStatusError as e:
        # Извлечение информации о перенаправлении
        if response.is_redirect:
            raise Exception(f"HTTP ошибка: Redirect response '{response.status_code} {response.reason_phrase}' for url '{response.url}'\nRedirect location: '{response.headers.get('Location')}'\nFor more information check: https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/{response.status_code}")
        else:
            raise Exception(f"HTTP ошибка: {e}")



    
    soup = BeautifulSoup(response.text, "html.parser")
    
    row_titles = soup.find_all("div", class_=lambda x: x and "rowTitle" in x)
    
    for row in row_titles:
        if row.text.strip().lower() == field.lower():
            parent = row.find_parent("div", class_="row")
            if not parent:
                continue

            data_columns = parent.find_all("div", class_=lambda x: x and "column" in x)
            data = [col.text.strip().replace(',', '') for col in data_columns]

            return tuple([row.text.strip()] + data)

    raise Exception(f"Поле '{field}' не найдено на странице.")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Использование: ./financial_enhanced.py 'TICKER' 'FIELD_NAME'")
        sys.exit(1)

    ticker_symbol = sys.argv[1]
    field_name = sys.argv[2]

    try:
        result = get_financial_data(ticker_symbol, field_name)
        print(result)
    except Exception as e:
        print(f"Ошибка: {e}")
        sys.exit(1)

#python3 -m cProfile -s time financial_enhanced.py 'MSFT' 'Total Revenue' > profiling-http.txt
