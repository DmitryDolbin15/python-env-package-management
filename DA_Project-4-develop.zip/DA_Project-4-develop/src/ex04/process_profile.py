
import pstats

def main():

    profile_file = 'profile_data.prof'
    p = pstats.Stats(profile_file)
    

    top_n = 5
    output_file = 'pstats-cumulative.txt'
    

    p.sort_stats('cumulative').print_stats(top_n)
    

if __name__ == "__main__":
    main()

#python3 process_profile.py > pstats-cumulative.txt
