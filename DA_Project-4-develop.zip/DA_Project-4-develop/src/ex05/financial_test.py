# ex05/financial_test.py

import pytest
from unittest.mock import patch
from financial import get_financial_data

@patch('financial.time.sleep', return_value=None)
def test_total_revenue_returns_correct_data(mock_sleep):
    """
    Тест проверяет, что запрос 'Total Revenue' для валидного тикера возвращает ожидаемые данные.
    """
    ticker = 'MSFT'
    field = 'Total Revenue'
    result = get_financial_data(ticker, field)
    
    # Проверяем, что результат - кортеж
    assert isinstance(result, tuple), "Результат должен быть кортежем."
    
    # Проверяем, что первый элемент - это название поля
    assert result[0].lower() == field.lower(), "Первый элемент должен быть названием поля."
    
    # Проверяем, что в кортеже есть хотя бы один элемент данных
    assert len(result) > 1, "Кортеж должен содержать данные."
    
    # Проверяем, что все элементы данных являются строками, представляющими числа
    for data_point in result[1:]:
        assert isinstance(data_point, str), "Элементы данных должны быть строками."
        # Проверяем, что строка представляет собой число
        assert data_point.replace(',', '').replace('.', '').isdigit(), f"Элемент данных '{data_point}' не является числом."


@patch('financial.time.sleep', return_value=None)
def test_invalid_ticker_raises_exception(mock_sleep):
    """
    Тест проверяет, что при передаче некорректного тикера функция вызывает исключение.
    """
    invalid_ticker = 'INVALIDTICKER123'
    field = 'Total Revenue'
    
    with pytest.raises(Exception) as exc_info:
        get_financial_data(invalid_ticker, field)
    
    # Проверяем сообщение об ошибке
    assert "Ошибка при загрузке страницы" in str(exc_info.value) or "Поле" in str(exc_info.value), "Сообщение об ошибке не соответствует ожидаемому."
